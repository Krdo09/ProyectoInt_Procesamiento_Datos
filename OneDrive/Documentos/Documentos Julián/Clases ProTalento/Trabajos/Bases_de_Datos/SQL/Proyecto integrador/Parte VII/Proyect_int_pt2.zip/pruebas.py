from Mapeo_Tablas import *
from Modelos import *
from Metodos import *
from tortoise.functions import Count


run_async(delete_operation(1))

